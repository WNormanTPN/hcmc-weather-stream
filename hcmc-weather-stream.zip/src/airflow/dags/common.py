import json
import os
from datetime import datetime
from pytz import timezone
from kafka import KafkaProducer


# Coordinates of districts in Ho Chi Minh City
DEST_COORDS = json.loads(os.getenv("OPENWEATHER_DEST_COORDS"))


# Timezone
VN_TZ = timezone("Asia/Ho_Chi_Minh")


# Kafka config
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC")
KAFKA_HOST = os.getenv("KAFKA_HOST").split(",")


def get_current_time():
    return datetime.now(VN_TZ).isoformat()


def default_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")


def send_to_kafka(data):
    print("Sending data to Kafka:", data)
    producer = KafkaProducer(bootstrap_servers=KAFKA_HOST)
    serialized = json.dumps(data, default=default_serializer).encode("utf-8")
    producer.send(KAFKA_TOPIC, value=serialized)
    producer.flush()
    producer.close()
    print("Data sent to Kafka successfully.")
