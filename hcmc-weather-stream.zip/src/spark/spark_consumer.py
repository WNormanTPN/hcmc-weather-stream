import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col


# Config Kafka
KAFKA_HOST = os.getenv("KAFKA_HOST")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC")


# Create SparkSession
spark = SparkSession.builder \
    .appName("Kafka to Parquet") \
    .getOrCreate()


# Read data from Kafka
df_raw = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_HOST) \
    .option("subscribe", KAFKA_TOPIC) \
    .load()


# Convert the Kafka value (which is in bytes) to string and parse it into JSON
df_parsed = df_raw.selectExpr("CAST(value AS STRING)") \
    .selectExpr("json_tuple(value, 'district', 'timestamp', 'temperature', 'humidity', 'wind_speed', 'source') as "
                "(district, timestamp, temperature, humidity, wind_speed, source)")


# Convert the columns to appropriate types
df = df_parsed \
    .withColumn("timestamp", col("timestamp").cast("timestamp")) \
    .withColumn("temperature", col("temperature").cast("float")) \
    .withColumn("humidity", col("humidity").cast("float")) \
    .withColumn("wind_speed", col("wind_speed").cast("float"))


# Write the data to Parquet
# Partition by 'district' so each worker will store a file per district
query = df.writeStream \
    .outputMode("append") \
    .format("parquet") \
    .option("checkpointLocation", "/tmp/checkpoint") \
    .partitionBy("district") \
    .option("path", "/path/to/parquet/output") \
    .start()


# Await termination
query.awaitTermination()
