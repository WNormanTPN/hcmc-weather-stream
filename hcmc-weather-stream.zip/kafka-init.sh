#!/bin/sh

echo "⏳ Waiting for Kafka brokers to be ready..."
sleep 15

echo "🛠️ Creating topic weather_data..."
kafka-topics --create \
  --topic weather_data \
  --partitions 3 \
  --replication-factor 3 \
  --if-not-exists \
  --bootstrap-server kafka-1:9093,kafka-2:9093,kafka-3:9093

echo "✅ Kafka topic 'weather_data' created (if not exists)"
